% ENG1003 Project 2 %

% Task 1 %
disp('Task 1')
disp('======')
clear all;
T1 = imread("T1.png");
sT1 = size(T1);
T1 = uint8(T1);

figure(1)
image(T1-186)

[center, radius] = imfindcircles(T1,[8,23]);

centerRounded = round(center);
radiusRounded = round(radius);
image(T1-186)
viscircles(centerRounded,radiusRounded);


centerRounded
radius
radiusRounded

AreaWithOriginalRadius = pi.*radius.^2
AreaWithRoundedRadius = pi.*radiusRounded.^2

yellowPixels = T1 == 255;
AreaNumYellowPixels = sum(yellowPixels(:))

d1 = 1;                         % Distance of sensor from surface %
FOV = 100 * pi/180;             % Conversion to radians %
diameterPixels = sqrt(60^2+80^2);    % Diameter of the total viewable area in meters %
diameterMeter = 2*d1*tan(FOV/2);     % Diameter of the total viewable area in meters %
pixelDistance = sqrt((centerRounded(1)).^2+(centerRounded(2)).^2); % Distance of circle from [1,1] in pixels %
k = diameterMeter./diameterPixels; % Pixel to meter proportion constant %
disp('Distance of center from (1,1) in meters: ')
DistanceMeters = k*pixelDistance
disp('Radius of the feature in meters: ')
RadiusMeters = k*radius
disp('Area of the feature in meters squared: ')
AreaMeters = pi*RadiusMeters.^2

disp('----------------------------------')

% Task 2%
disp('Task 2')
disp('======')
Threshold = 0.1 % Value must be between 0 and 1 %
T2 = imread("T2.png");
sT2 = size(T2);
T2 = double(T2);

figure(2)
image(T2-186)

[center, radius] = imfindcircles(T2,[8,23],'EdgeThreshold',Threshold);

centerRounded = round(center);
radiusRounded = round(radius);
image(T2)
viscircles(centerRounded,radiusRounded);


centerRounded
radius
radiusRounded

AreaWithOriginalRadius = pi.*radius.^2
AreaWithRoundedRadius = pi.*radiusRounded.^2

yellowPixels = T2 >= 1.4*Threshold*255;
AreaNumYellowThresholdingPixels = sum(yellowPixels(:))

d2 = 1;                         % Distance of sensor from surface %
FOV = 100 * pi/180;             % Conversion to radians %
diameterPixels = sqrt(60^2+80^2);    % Diameter of the total viewable area in meters %
diameterMeter = 2*d2*tan(FOV/2);     % Diameter of the total viewable area in meters %
pixelDistance = sqrt((centerRounded(1)).^2+(centerRounded(2)).^2); % Distance of circle from [1,1] in pixels %
k = diameterMeter./diameterPixels; % Pixel to meter proportion constant %
disp('Distance of center from (1,1) in meters: ')
DistanceMeters = k*pixelDistance
disp('Radius of the feature in meters: ')
RadiusMeters = k*radius
disp('Area of the feature in meters squared: ')
AreaMeters = pi*RadiusMeters.^2
